print("Calculate the area of a wall.") 

# Ask for width 
X = input("Enter the width in meters: ") 
Width = float(X) 

# Ask for height 
Y = input("enter the height in meters: ") 
Height = float(Y) 

# Show entered values 
print(f"Width is {Width} m and Height is {Height} m.") 

# calculate area 
Area = Width * Height 

# Show result 
print(f"The wall will be {Area} square meters")
